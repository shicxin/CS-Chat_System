#include<stdio.h>
#include"../lib/init.h"
#include"../lib/user.h"
#include"../lib/tell.h"

int main(int argc, char** argv)
{
	// bool* ID_linked_list;
	if(PUT_OK)
	{
		printf("一共%d, 分别是",argc);
		for(int i = 0; i < argc; i++)
		{
			printf("%s ", argv[i]);
		}
	}
	HEAD head;
	init_ser_file();
	init_ser_sys(&head);
	//开始监听端口
	int ser_sock, cln_sock[30];
	struct sockaddr_in ser_addr, cln_addr;
	ser_sock = socket(PF_INET, SOCK_STREAM, 0);
	if(ser_sock == -1) 
	{
		puts("socket error!");
		exit(1);
	}
	memset(&ser_addr, 0, sizeof(ser_addr));
	ser_addr.sin_family = AF_INET;
	// ser_addr.sin_port = htons(PORT_log);
	printf("监听端口为：");
	int port;
	scanf("%d", &port);
	ser_addr.sin_port = htons(port);
	ser_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	if(bind(ser_sock, (struct sockaddr*)&ser_addr, sizeof(ser_addr)) == -1)
	{
		puts("bind error!");
		exit(1);
	}
	if(listen(ser_sock, 30) == -1)
	{
		puts("listen error!");
		exit(1);
	}
	USER* x = (USER*)malloc(sizeof(USER));
	x->next = head.onli_ur;
	head.onli_ur = x;
	int i = 0;
	{
		x->sock = wait_cln(&ser_sock, cln_addr);
		while(1)
		{
			talk_cln(&head, x);
			if(PUT_OK) printf("结束一次循环");
		}
		sleep(10);
		close(x->sock);
	}
	close(ser_sock);
	return 0;
}
