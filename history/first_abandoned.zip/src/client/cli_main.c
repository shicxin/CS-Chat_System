#include <stdio.h>
#include <unistd.h>
#include "../lib/user.h"
#include "../lib/init.h"
#include "../lib/tell.h"


int main(int argc, char** argv)
{
	if(PUT_OK)
	{
		printf("一共%d, 分别是",argc);
		for(int i = 0; i < argc; i++)
		{
			printf("%s ", argv[i]);
		}
		printf("\n");
	}
	Welcome_Screen();
	USER x;//保存当前用户信息
	bool k = 0;
	int q = 0;
	int sock = call_ser();
	x.sock = sock;
	printf("sock id %d, x.sock is %d\n", sock, x.sock);
	if(x.sock < 0) puts("服务器开小差了，请联系管理员");
	else k = 1;
	while(k)
	{
		if(create_or_login(&x) == 1) 
		{
			k = 0;
			q = 1;
		}
	}
	while(q)
	{
		puts("进入系统！");
		// write(sock, "hello_ser", 10);
		// puts("OK");
		// char message[100];
		// read(sock, message, 10);
		// if(PUT_OK) printf("?%s\n", message);
		// memset(message, 0, sizeof(message));
		break;
	}
	close(x.sock);
	return 0;
}