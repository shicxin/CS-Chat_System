#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/stat.h>
#include "user.h"
#include "tell.h"

/// @brief 登录或注册函数
/// @param x 用户结构体
/// @param sig 
/// @return 
bool create_or_login(USER* x) 
{
	puts("你想要执行什么操作：（登录0、注册1、其余任意键无效）");
	char c[2];
	memset(c, 0, sizeof(c));
	scanf("%s", c);
	int sig = atoi(&c[0]);
//！！！！！！！！！！！！！！收集信息！！！！！！！！！！！！！！！！
	if(sig == 1)//注册信号
	{
		bool k = 1;sig = 10;
		while(k)
		{
			printf("请输入用户名:\t");
			scanf("%s", x->name);
			printf("请输密码:\t");
			scanf("%s", x->pasw);
			char pas[CHAR_SIZE];
			printf("请确认密码:\t");
			scanf("%s", pas);
			if(strcmp(pas, x->pasw) == 0) k = 0;
			else puts("two different passwords");
		}
	}
	else if(sig == 0)//登录
	{
		printf("请输入用户ID:\t");
		scanf("%s", x->ID);
		sig = 11;
		printf("请输密码:\t");
		scanf("%s", x->pasw);
	}

//！！！！！！！！发送消息！！！！！！！！！！

	char* message = user_to_json(x);
	SIG signal, sig_OK;
	signal.DO = sig;
	int len = strlen(message) + 1;//fuck ,this must add one. dont ask why, i use One hour find this BUG;
	int_to_str(signal.len, &len);
	signal.tim = time(NULL);
	char* js = signal_to_json(&signal);
	len = write(x->sock, js, strlen(js));//信号
	printf("x.sock is %d\n", x->sock);
	if(PUT_OK) printf("cln发送信号len = %d\n", len);
	if(PUT_OK) puts(js);
	len = write(x->sock, message, strlen(message) + 1);//消息
	if(PUT_OK) printf("%ld\n", strlen(message) + 1);
	if(PUT_OK) printf("cln发送内容len = %d\n", len);
	if(PUT_OK) puts(message);
	message = (char*) malloc(sizeof(char) * SIG_LEN);
	memset(message, 0, sizeof(message));
	/*****接收消息*/
	len = read(x->sock, message, SIG_LEN);//接收是否成功创建账号以及更新之前的账号信息
	if(PUT_OK) printf("cln收到内容len = %d\n", len);
	if(PUT_OK) printf("%s\n", message);
	json_to_signal(&sig_OK, message);
	print_sig_OK(&signal, &sig_OK);
	memset(message, 0, sizeof(message));
	// printf("本次信号长度为%ld字节\n", strlen(js));
	// printf("本次信号长度为%ld字节\n", strlen(message));
	str_to_int(sig_OK.len, &len);
	if(PUT_OK) printf("cln将会收到内容len = %d\n", len);
	len = read(x->sock, message, len);
	if(PUT_OK) printf("cln收到内容len = %d\n", len);
	if(PUT_OK) printf("%s\n", message);
	json_to_user(x, message);
	free(message);
	free(js);
	if(sig_OK.DO == 98 && signal.DO == 11) return 1;
	else return 0;
}

/// @brief 向系统中添加用户
/// @param head 头结点
/// @param x 新加未分配节点用户
/// @return 返回是否创建成功
bool add_user(HEAD* head, USER* x)
{
	char id[CHAR_SIZE];
	Allocation_ID(head->all_ur, id);
	strcpy(x->ID, id);
	x->next = head->all_ur;
	head->all_ur = x;
	if(PUT_OK)puts("新用户添加链表成功");
	return writ_neus_to_fi(x);
}

/// @brief 分配未被占用的ID
/// @param head 系统用户列表
/// @param id 分配到的ID
void Allocation_ID(USER* head, char* id)
{
	int max = 1000000;
	while(head != NULL)
	{
		max = (max > atoi(head->ID)) ? max : atoi(head->ID);//找到目前最大的ID
		head = head->next;
	}
	max++;//创建新的最大ID
	sprintf(id, "%d", max);
	if(PUT_OK)puts("新用户分配ID成功");
}

/// @brief 将用户信息写入文件
/// @param user 用户信息
bool writ_neus_to_fi(USER* user)
{
	char fnm[WHERE_SIZE] = "./data/user/\0";
	strcat(fnm, user->ID);
	mkdir(fnm, 0777);//创建用户文件夹
	char frdnm[WHERE_SIZE];
	strcpy(frdnm, fnm);
	FILE* fd = NULL, *frdfd = NULL, *grofd = NULL;

	strcat(frdnm, "/firend");//用户好友信息文件
	strcat(fnm, "/group");//用户群聊信息文件
	// puts(frdnm);
	// puts(fnm);
	frdfd = fopen(frdnm, "w");
	grofd = fopen(fnm, "w");
	fd = fopen("./data/sys/all_user", "a");
	if(fd == NULL)
	{
		puts("打开总用户文件夹失败！");
		return 0;
	}
	if(frdfd == NULL)
	{
		puts("创建新用户文件夹失败！");
		return 0;
	}
	if(grofd == NULL)
	{
		puts("创建新用户文件夹失败！");
		return 0;
	}
	fprintf(fd, "%s %s %s\n", user->ID, user->name, user->pasw);//用户ID、用户名、用户密码、
	Fred_and_Grp *f = user->r.frdliste, *g = user->l.groplist;
	while(f != NULL)
	{
		fprintf(frdfd, "%s\n", f->ID);//好友ID
		f = f->next;
	}
	while(g != NULL)
	{
		fprintf(grofd, "%s\n", g->ID);//群聊ID
		g = g->next;
	}
	fclose(fd);
	fclose(frdfd);
	fclose(grofd);
	if(PUT_OK)puts("新用户写文件成功");
	return 1;
}

/// @brief 根据ID寻找用户，使用前注意判断当前节点
/// @return 返回指向用户的节点
USER* find_user_use_ID(USER* head, char* id)
{
	while(head->next != NULL)
	{
		if(strcmp(head->next->ID, id) == 0)
		{
			return head;
		}
		head = head->next;
	}
	return NULL;
}

/// @brief 用户登录函数返回登录状态，
/// @param head 
/// @param x 
/// @return 
int user_login(USER* head, USER* x)
{
	//如果后面不要使用这个参数，千万不要释放他的内存
	USER* user = NULL;
	if(head == NULL) return 0;
	if(strcmp(head->ID, x->ID) == 0)
	{
		user = head;
	}
	else user = find_user_use_ID(head, x->ID);
	if(user == NULL) return 0;
	else if(strcmp(user->pasw, x->pasw))
	{
		memcpy(x, user, sizeof(user));
		return 1;
	}
	else return -1;
}

/// @brief 注销用户
/// @param head 服务端用户链表
/// @param x 需要删除的用户信息
void del_user(USER* head, USER* x)
{
	USER* user = NULL;
	if(head == NULL) return ;
	if(strcmp(head->ID, x->ID) == 0)
	{
		if(strcmp(head->pasw, x->pasw))
		{
			free(head);
			head = NULL;
			puts("删除成功！");
		}
		else puts("密码错误,删除失败！");
		return;
	}
	user = find_user_use_ID(head, x->ID);
	if(user == NULL) 
	{
		puts("没有找到账号！");
		return;
	}
	else 
	{
		if(strcmp(user->pasw, x->pasw))
		{
			user = head->next;
			head->next = head->next->next;
			free(user);
			////////////////////////////////////////更新文件信息
		}
		else puts("密码错误,删除失败！");
	}
}

/// @brief 看用户链表
/// @param head 
void look_linked_list(USER* head)
{
	while(head != NULL)
	{
		printf("user id: %s, user name: %s, user pasw: %s\n", head->ID, head->name, head->pasw);
		head = head->next;
	}
}

/// @brief 服务端收到注册信号后的处理
/// @param head 用户链表
/// @param x 客户端发来的注册人信息
/// @param sock 注册客户端套接字
void register_requests( HEAD* head, USER* x, int sock)
{
	SIG sig;
	sig.DO = add_user(head, x) ? 98 : 99;//Create a user and judge whether the creation is successful
	sig.tim = time(NULL);
	char* message; //becouse next operation while get new memory space address
	message = user_to_json(x);
	if(PUT_OK) printf("%s\n", message);
	int len = strlen(message) + 1;
	int_to_str(sig.len, &len);
	char* temp = signal_to_json(&sig);
	if(PUT_OK)puts("新用户创建成功");
	if(PUT_OK) printf("%s\n", temp);
	write(sock, temp, SIG_LEN);//告诉客户端注册是否成功
	// if(PUT_OK) printf("写信号长度len = %d\n", len);
	len = write(sock, message, len);//告诉客户端注册账号
	if(PUT_OK) printf("写内容长度len = %d\n", len);
	free(temp);
	free(message);
	// look_linked_list(head->all_ur);
}

/// @brief 服务端收到登录信号后进行反馈
/// @param head 用户链表
/// @param x 客户端发来的注册人信息
/// @param sock 注册客户端套接字
void login_requests(HEAD* head, USER* x, int sock)
{
	SIG sig;
	sig.DO = 99;
	sig.tim = time(NULL);
	if(user_login(head->all_ur, x))
	{
		x->next = head->onli_ur;
		head->onli_ur = x;
		x->sock = sock;
		sig.DO = 98;
	}
	USER* user = x;
	char* message = user_to_json(user);
	int len = strlen(message) + 1;
	int_to_str(sig.len, &len);
	char* temp = signal_to_json(&sig);
	write(sock, temp, SIG_LEN);
	write(sock, message, len);
	free(temp);
	// look_linked_list(head->all_ur);
}

















void print_sig_OK(SIG* sig_send, SIG* sig_return)
{
	if(sig_return->DO == 99)
	{
		if(sig_send->DO == 10) printf("注册");
		else if(sig_send->DO == 11) printf("登录");
		else if(sig_send->DO == 12) printf("注销");
		else if(sig_send->DO == 13) printf("修改密码");
		else if(sig_send->DO == 14) printf("添加用户");
		else if(sig_send->DO == 15) printf("删除用户");
		else if(sig_send->DO == 21) printf("创建聊天群");
		else if(sig_send->DO == 22) printf("删除聊天群");
		else if(sig_send->DO == 23) printf("群聊加人");
		else if(sig_send->DO == 24) printf("群聊删人");
		else if(sig_send->DO == 25) printf("群主换人");
		else if(sig_send->DO == 31) printf("传输消息");
		else if(sig_send->DO == 32) printf("发送撤回消息");
		else if(sig_send->DO == 33) printf("撤回消息");
		else if(sig_send->DO == 44) printf("异地登录或太久没与服务器聊天,登录");
		else puts("没有这个信号");
		puts("失败");
	}
	else if(sig_return->DO == 98)
	{
		if(sig_send->DO == 10) printf("注册");
		else if(sig_send->DO == 11) printf("登录");
		else if(sig_send->DO == 12) printf("注销");
		else if(sig_send->DO == 13) printf("修改密码");
		else if(sig_send->DO == 14) printf("添加用户");
		else if(sig_send->DO == 15) printf("删除用户");
		else if(sig_send->DO == 21) printf("创建聊天群");
		else if(sig_send->DO == 22) printf("删除聊天群");
		else if(sig_send->DO == 23) printf("群聊加人");
		else if(sig_send->DO == 24) printf("群聊删人");
		else if(sig_send->DO == 25) printf("群主换人");
		else if(sig_send->DO == 31) printf("传输消息");
		else if(sig_send->DO == 32) printf("发送撤回消息");
		else if(sig_send->DO == 33) printf("撤回消息");
		else if(sig_send->DO == 44) printf("异地登录或太久没与服务器聊天,登录");
		else puts("没有这个信号");
		puts("成功");
	}
	else puts("没有这个信号");
}


