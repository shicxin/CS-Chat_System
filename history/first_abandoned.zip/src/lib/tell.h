#if !defined(__TELL__)
#define __TELL__

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <time.h>
#include "user.h"
#include "cJSON.h"

#if !defined(__CHARSIZE__)
#define __CHARSIZE__
#define CHAR_SIZE 20
#define WHERE_SIZE 50
#endif // __CHARSIZE__


#define PORT_log 8888
#define SIG_LEN 52
#define PUT_OK 1

typedef struct signal
{
    int DO;
    char len[10]; //下次接收文件长度
    time_t tim;//时间
}SIG;//数据头


/*************clion*******************/
//与客户端发起连接，获得聊天套接字
int call_ser();
//打印服务器返回消息
void print_sig_OK(SIG* sig_send, SIG* sig_return);


/*************server*******************/
int wait_cln(int* ser_sock, struct sockaddr_in cln_addr);//服务器监听端口
void talk_cln(HEAD*, USER* );//等待客户端消息


/****************cjson****************/
char* signal_to_json(SIG* );
void json_to_signal(SIG* , char*);

char* user_to_json(USER* );
void json_to_user(USER* , char* );


/**************SIG*******************/
void int_to_str(char*, int*);
void str_to_int(char*, int*);
#endif // __TELL__
